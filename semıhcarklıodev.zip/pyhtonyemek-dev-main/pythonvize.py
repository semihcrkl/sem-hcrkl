class Yemek:
    yemekler = []
    yemek = input("Yemek ismi: ")
    yemekler.append(yemek)
    for x in yemekler:
        print(x)
    
class Tarif(Yemek):
    tarifler = []
    tarif = input("Tarif Gir :")
    tarifler.append(tarif)
    for x in tarifler:
        print(x)




    